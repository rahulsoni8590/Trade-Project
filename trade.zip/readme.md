
//   /*  Test successful signup and login.
// - Test error handling for duplicate username or invalid credentials.
    
//     Test creating an asset (both draft and published).
//     - Test listing an asset on the marketplace.
//     - Test retrieving asset details.
//     - Test retrieving user's assets.

//     Test retrieving assets on the marketplace.
// - Test creating a purchase request.
// - Test negotiating a purchase request.
// - Test accepting a purchase request.
// - Test denying a purchase request.
// - Test retrieving user's purchase requests.*/